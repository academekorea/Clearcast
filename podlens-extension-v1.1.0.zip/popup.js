// Podlens Extension — popup.js
// State machine: not-logged-in | no-episode | episode-detected | analyzing | analysis-complete | error

const PODLENS = 'https://podlens.app';

// ── i18n ──────────────────────────────────────────────────────────────────────

const i18n = {
  en: {
    headerTagline: "Know what you're actually listening to",
    signinHead: 'Sign in to analyze episodes',
    signinSub: 'Paste a podcast URL or use the extension on any YouTube or Spotify episode.',
    signinBtn: 'Sign in to Podlens',
    signinRefresh: "I've signed in — refresh",
    signinTrial: '✓ Free 7-day trial · No card needed',
    noEpMsg: 'Navigate to a podcast episode to analyze it.',
    noEpOpen: 'Open Podlens ↗',
    analyzeBtn: 'Analyze this episode',
    eta: 'Usually 30–90 seconds',
    cancelBtn: 'Cancel',
    steps: [
      '🔍 Extracting transcript...',
      '📊 Identifying topics...',
      '⚖ Analyzing framing...',
      '👤 Evaluating host trust...',
      '🔎 Detecting missing voices...'
    ],
    politicalLean: 'POLITICAL LEAN',
    footnote: 'Based on language patterns and framing — not a judgment of the host\'s personal politics',
    upgradeNudge: 'Upgrade to see full scores',
    upgradeLinkText: 'See plans ↗',
    seeFullAnalysis: 'See full analysis ↗',
    copyLink: '📋 Copy',
    copied: '✓ Copied!',
    shareX: '𝕏 Share',
    recentHead: 'Recent analyses',
    planLabels: { free: 'Free', trial: 'Trial', creator: 'Creator', operator: 'Operator', studio: 'Studio' },
    platforms: { youtube: 'YouTube', spotify: 'Spotify', apple: 'Apple Podcasts', podbean: 'Podbean', soundcloud: 'SoundCloud' }
  },
  ko: {
    headerTagline: '당신이 실제로 듣고 있는 것을 알아보세요',
    signinHead: '에피소드를 분석하려면 로그인하세요',
    signinSub: '팟캐스트 URL을 붙여넣거나 YouTube, Spotify 에피소드에서 확장 프로그램을 사용하세요.',
    signinBtn: 'Podlens 로그인',
    signinRefresh: '로그인 완료 — 새로고침',
    signinTrial: '✓ 7일 무료 체험 · 카드 불필요',
    noEpMsg: '분석할 팟캐스트 에피소드로 이동하세요.',
    noEpOpen: 'Podlens 열기 ↗',
    analyzeBtn: '이 에피소드 분석하기',
    eta: '보통 30–90초',
    cancelBtn: '취소',
    steps: [
      '🔍 트랜스크립트 추출 중...',
      '📊 토픽 식별 중...',
      '⚖ 프레이밍 분석 중...',
      '👤 호스트 신뢰도 평가 중...',
      '🔎 누락된 관점 탐지 중...'
    ],
    politicalLean: '정치적 성향',
    footnote: '언어 패턴과 프레이밍에 기반 — 호스트 개인 정치에 대한 판단이 아닙니다',
    upgradeNudge: '전체 점수를 보려면 업그레이드',
    upgradeLinkText: '플랜 보기 ↗',
    seeFullAnalysis: '전체 분석 보기 ↗',
    copyLink: '📋 복사',
    copied: '✓ 복사됨!',
    shareX: '𝕏 공유',
    recentHead: '최근 분석',
    planLabels: { free: '무료', trial: '체험', creator: '크리에이터', operator: '오퍼레이터', studio: '스튜디오' },
    platforms: { youtube: 'YouTube', spotify: 'Spotify', apple: 'Apple Podcasts', podbean: 'Podbean', soundcloud: 'SoundCloud' }
  }
};

const isKorean = navigator.language.startsWith('ko');
const T = isKorean ? i18n.ko : i18n.en;

// ── State helpers ─────────────────────────────────────────────────────────────

function showState(id) {
  document.querySelectorAll('.pl-state').forEach(el => el.classList.remove('active'));
  const el = document.getElementById('state-' + id);
  if (el) el.classList.add('active');
}

function applyTranslations() {
  document.getElementById('pl-header-tagline').textContent = T.headerTagline;
  document.getElementById('signin-head').textContent = T.signinHead;
  document.getElementById('signin-sub').textContent = T.signinSub;
  document.getElementById('signin-btn').textContent = T.signinBtn;
  document.getElementById('signin-refresh-btn').textContent = T.signinRefresh;
  document.getElementById('signin-trial').textContent = T.signinTrial;
  document.getElementById('no-ep-msg').textContent = T.noEpMsg;
  document.getElementById('no-ep-open-btn').textContent = T.noEpOpen;
  document.getElementById('analyze-btn').textContent = T.analyzeBtn;
  document.getElementById('analyzing-eta').textContent = T.eta;
  document.getElementById('cancel-btn').textContent = T.cancelBtn;
  document.getElementById('lbl-political-lean').textContent = T.politicalLean;
  document.getElementById('result-footnote').textContent = T.footnote;
  document.getElementById('upgrade-nudge-text').textContent = T.upgradeNudge;
  document.getElementById('upgrade-nudge-link').textContent = T.upgradeLinkText;
  document.getElementById('share-copy').textContent = T.copyLink;
  document.getElementById('share-x').textContent = T.shareX;
  // Translate steps
  const steps = document.querySelectorAll('#analyzing-steps .pl-step');
  T.steps.forEach((s, i) => { if (steps[i]) steps[i].textContent = s; });
}

// ── Platform helpers ──────────────────────────────────────────────────────────

function getPlatform(url) {
  if (!url) return null;
  if (/youtube\.com\/watch/.test(url)) return 'youtube';
  if (/open\.spotify\.com\/episode/.test(url)) return 'spotify';
  if (/podcasts\.apple\.com/.test(url)) return 'apple';
  if (/podbean\.com\/e\//.test(url)) return 'podbean';
  if (/soundcloud\.com/.test(url)) return 'soundcloud';
  return null;
}

function platformLabel(platform) {
  return T.platforms[platform] || platform;
}

function platformClass(platform) {
  const map = { youtube: 'ep-platform-yt', spotify: 'ep-platform-sp', apple: 'ep-platform-ap', podbean: 'ep-platform-pb', soundcloud: 'ep-platform-sc' };
  return map[platform] || 'ep-platform-yt';
}

function setPlatformPill(el, platform) {
  el.textContent = platformLabel(platform);
  el.className = 'pl-ep-platform ' + platformClass(platform);
}

// ── Plan badge ────────────────────────────────────────────────────────────────

function showPlanBadge(plan) {
  const badge = document.getElementById('pl-plan-badge');
  if (!plan || plan === 'free') { badge.style.display = 'none'; return; }
  badge.textContent = T.planLabels[plan] || plan;
  badge.className = 'pl-plan-badge badge-' + plan;
  badge.style.display = '';
}

function canAccess(feature, plan) {
  const tiers = {
    fullBiasScores: ['creator', 'operator', 'studio'],
    sourceCitations: ['operator', 'studio'],
    findings: ['operator', 'studio']
  };
  return tiers[feature]?.includes(plan) || false;
}

// ── Recent analyses ───────────────────────────────────────────────────────────

function renderRecentBlock(containerEl, recent) {
  if (!recent || recent.length === 0) { containerEl.innerHTML = ''; return; }
  const shown = recent.slice(0, 3);
  let html = `<div class="pl-hr"></div><div class="pl-recent-head">${T.recentHead}</div>`;
  for (const item of shown) {
    const l = item.leftPct || 0;
    const c = item.centerPct || 20;
    const r = item.rightPct || 0;
    const barGrad = `linear-gradient(to right, #E24B4A ${l}%, #D1CFC9 ${l}% ${l + c}%, #378ADD ${l + c}%)`;
    const title = (item.episodeTitle || 'Episode').substring(0, 40);
    const show = (item.channel || '').substring(0, 28);
    const href = item.analysisUrl || PODLENS;
    html += `
      <a class="pl-recent-item" href="${escapeHtml(href)}" target="_blank">
        <div class="pl-recent-bias" style="background:${barGrad}"></div>
        <div class="pl-recent-text">
          <div class="pl-recent-ep">${escapeHtml(title)}</div>
          ${show ? `<div class="pl-recent-show">${escapeHtml(show)}</div>` : ''}
        </div>
        <span class="pl-recent-arrow">&#x2197;</span>
      </a>`;
  }
  containerEl.innerHTML = html;
}

function escapeHtml(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

// ── Bias bar rendering ────────────────────────────────────────────────────────

function renderBiasBar(l, c, r, plan) {
  const bar = document.getElementById('result-bar');
  bar.style.background = `linear-gradient(to right, #E24B4A ${l}%, #D1CFC9 ${l}% ${l + c}%, #378ADD ${l + c}%)`;

  const pcts = document.getElementById('result-pcts');
  document.getElementById('result-pct-left').textContent = `🔴 ${l}% left`;
  document.getElementById('result-pct-ctr').textContent = `⬜ ${c}% center`;
  document.getElementById('result-pct-right').textContent = `🔵 ${r}% right`;

  const showFull = canAccess('fullBiasScores', plan);
  if (!showFull) {
    pcts.classList.add('blurred');
    document.getElementById('result-upgrade-nudge').style.display = '';
  } else {
    pcts.classList.remove('blurred');
    document.getElementById('result-upgrade-nudge').style.display = 'none';
  }
}

function renderFindings(findings, plan) {
  const el = document.getElementById('result-findings');
  if (!findings || !findings.length || !canAccess('findings', plan)) {
    el.innerHTML = '';
    return;
  }
  el.innerHTML = findings.slice(0, 2).map(f =>
    `<div class="pl-finding"><strong>${escapeHtml(f.title || '')}</strong>${f.detail ? escapeHtml(f.detail) : ''}</div>`
  ).join('');
}

// ── Sharing ───────────────────────────────────────────────────────────────────

let currentAnalysisUrl = null;
let currentEpisodeTitle = '';

document.getElementById('share-copy').addEventListener('click', () => {
  const url = currentAnalysisUrl || PODLENS;
  navigator.clipboard.writeText(url).then(() => {
    const btn = document.getElementById('share-copy');
    const orig = btn.textContent;
    btn.textContent = T.copied;
    btn.classList.add('copied');
    setTimeout(() => { btn.textContent = orig; btn.classList.remove('copied'); }, 1800);
  }).catch(() => {});
});

document.getElementById('share-x').addEventListener('click', () => {
  const url = currentAnalysisUrl || PODLENS;
  const text = encodeURIComponent(`Just analyzed "${currentEpisodeTitle}" on Podlens — see the political lean breakdown:`);
  chrome.tabs.create({ url: `https://twitter.com/intent/tweet?text=${text}&url=${encodeURIComponent(url)}` });
});

document.getElementById('share-kakao').addEventListener('click', () => {
  const url = currentAnalysisUrl || PODLENS;
  chrome.tabs.create({ url: `${PODLENS}/?share=kakao&url=${encodeURIComponent(url)}` });
});

// ── Auth handlers ─────────────────────────────────────────────────────────────

document.getElementById('signin-btn').addEventListener('click', (e) => {
  e.preventDefault();
  const extId = chrome.runtime.id;
  const authUrl = `${PODLENS}/auth?source=extension&extensionId=${extId}`;
  chrome.tabs.create({ url: authUrl });
});

document.getElementById('signin-refresh-btn').addEventListener('click', () => {
  init();
});

// ── Cancel analysis ───────────────────────────────────────────────────────────

document.getElementById('cancel-btn').addEventListener('click', () => {
  chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
    if (tab?.id) {
      chrome.storage.session.remove('tab_' + tab.id);
      chrome.tabs.sendMessage(tab.id, { type: 'CANCEL_ANALYSIS' }).catch(() => {});
    }
    init();
  });
});

// ── Error retry ───────────────────────────────────────────────────────────────

document.getElementById('error-retry-btn').addEventListener('click', () => {
  chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
    if (tab?.id) {
      chrome.tabs.sendMessage(tab.id, { type: 'TRIGGER_ANALYSIS' }).catch(() => {});
      window.close();
    }
  });
});

// ── Analyze button ────────────────────────────────────────────────────────────

document.getElementById('analyze-btn').addEventListener('click', () => {
  chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
    if (!tab?.id) return;
    const injectAndTrigger = () => {
      chrome.tabs.sendMessage(tab.id, { type: 'TRIGGER_ANALYSIS' }).catch(() => {
        chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content.js'] }).then(() => {
          chrome.scripting.insertCSS({ target: { tabId: tab.id }, files: ['sidebar.css'] });
          setTimeout(() => {
            chrome.tabs.sendMessage(tab.id, { type: 'TRIGGER_ANALYSIS' }).catch(() => {});
          }, 300);
        }).catch(() => {});
      });
    };
    injectAndTrigger();
    window.close();
  });
});

// ── Step update from storage ──────────────────────────────────────────────────

function updateSteps(step) {
  document.querySelectorAll('#analyzing-steps .pl-step').forEach((el, i) => {
    el.classList.remove('active', 'done');
    if (i < step) el.classList.add('done');
    else if (i === step) el.classList.add('active');
  });
}

// ── Main init ─────────────────────────────────────────────────────────────────

async function init() {
  applyTranslations();

  // Korean share button
  if (isKorean) {
    document.getElementById('share-kakao').style.display = '';
  }

  // Load auth
  const { pl_auth: auth } = await chrome.storage.local.get('pl_auth');

  if (!auth || !auth.token || (auth.expiresAt && Date.now() > auth.expiresAt)) {
    showState('not-logged-in');
    return;
  }

  const plan = auth.plan || 'free';
  showPlanBadge(plan);

  // Load recent analyses
  const { pl_recent: recent = [] } = await chrome.storage.local.get('pl_recent');

  // Get active tab
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const url = tab?.url || '';
  const platform = getPlatform(url);

  // Check for in-progress analysis on this tab
  if (tab?.id) {
    const sessionKey = 'tab_' + tab.id;
    const sessionData = await chrome.storage.session.get(sessionKey);
    const tabState = sessionData[sessionKey];

    if (tabState) {
      if (tabState.status === 'analyzing' || tabState.status === 'pending') {
        // Reconnect to in-progress analysis
        showState('analyzing');
        document.getElementById('analyzing-ep-title').textContent = tabState.title || 'Analyzing episode...';
        updateSteps(tabState.step || 0);
        // Listen for updates
        chrome.storage.onChanged.addListener(onStorageChange(tab.id));
        return;
      }

      if (tabState.status === 'complete') {
        renderCompleteState(tabState, plan, tab);
        return;
      }

      if (tabState.status === 'error') {
        showState('error');
        document.getElementById('error-msg').textContent = tabState.error || 'Analysis failed.';
        if (tab.url) document.getElementById('error-open-link').href = `${PODLENS}/?url=${encodeURIComponent(tab.url)}`;
        return;
      }
    }
  }

  // No active analysis
  if (platform) {
    // Episode page detected — get episode info from content script
    showState('episode-detected');

    // Try to get info from content script
    if (tab?.id) {
      chrome.tabs.sendMessage(tab.id, { type: 'GET_EPISODE_INFO' }, (info) => {
        if (chrome.runtime.lastError || !info) {
          // Content script not loaded yet — use basic URL info
          populateEpisodeState(platform, url, '', '', recent);
          return;
        }
        populateEpisodeState(platform, info.url || url, info.title || '', info.channel || '', recent);
      });
    } else {
      populateEpisodeState(platform, url, '', '', recent);
    }
  } else {
    // Not on a podcast page
    showState('no-episode');
    renderRecentBlock(document.getElementById('no-ep-recent'), recent);
  }
}

function populateEpisodeState(platform, url, title, channel, recent) {
  const pill = document.getElementById('ep-platform-pill');
  setPlatformPill(pill, platform);

  document.getElementById('ep-title').textContent = title || url.split('?')[0].split('/').pop() || 'Episode';
  document.getElementById('ep-channel').textContent = channel;

  renderRecentBlock(document.getElementById('ep-detected-recent'), recent);
}

function renderCompleteState(tabState, plan, tab) {
  showState('analysis-complete');

  const platform = getPlatform(tab?.url || '');
  if (platform) {
    setPlatformPill(document.getElementById('result-platform-pill'), platform);
  }

  document.getElementById('result-ep-title').textContent = tabState.title || 'Episode';
  document.getElementById('result-ep-channel').textContent = tabState.channel || '';

  const l = tabState.leftPct || 0;
  const c = tabState.centerPct || 0;
  const r = tabState.rightPct || 0;

  renderBiasBar(l, c, r, plan);

  document.getElementById('result-plain').textContent = tabState.biasLabel || '';
  renderFindings(tabState.findings || [], plan);

  currentAnalysisUrl = tabState.analysisUrl || PODLENS;
  currentEpisodeTitle = tabState.title || 'this episode';

  const fullLink = document.getElementById('result-full-link');
  fullLink.href = currentAnalysisUrl;
  fullLink.textContent = T.seeFullAnalysis;
}

function onStorageChange(tabId) {
  const key = 'tab_' + tabId;
  return function handler(changes, area) {
    if (area !== 'session' || !changes[key]) return;
    const state = changes[key].newValue;
    if (!state) return;

    if (state.status === 'analyzing' || state.status === 'pending') {
      updateSteps(state.step || 0);
    } else if (state.status === 'complete') {
      chrome.storage.local.get('pl_auth', ({ pl_auth: auth }) => {
        const plan = auth?.plan || 'free';
        renderCompleteState(state, plan, { id: tabId, url: state.url });
      });
      chrome.storage.onChanged.removeListener(handler);
    } else if (state.status === 'error') {
      showState('error');
      document.getElementById('error-msg').textContent = state.error || 'Analysis failed.';
      chrome.storage.onChanged.removeListener(handler);
    }
  };
}

// ── Boot ──────────────────────────────────────────────────────────────────────

init().catch(console.error);
