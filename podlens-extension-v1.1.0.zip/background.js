// Podlens Extension — background.js
// Service worker: auth, API calls, analysis polling, state persistence

const API = 'https://podlens.app/api';
const MAX_POLLS = 80; // ~4 minutes (80 × 3s)

// ── Message routing ───────────────────────────────────────────────────────────

chrome.runtime.onMessage.addListener((msg, sender) => {
  if (msg.type === 'ANALYZE') {
    analyzeEpisode(msg, sender.tab?.id);
  }
});

// Auth from podlens.app website (externally_connectable)
chrome.runtime.onMessageExternal.addListener((msg, sender) => {
  if (sender.origin !== 'https://podlens.app') return;
  if (msg.type === 'PODLENS_AUTH' && msg.token) {
    const expiresAt = msg.expiresAt || (Date.now() + 7 * 24 * 60 * 60 * 1000);
    chrome.storage.local.set({
      pl_auth: {
        token: msg.token,
        userId: msg.userId || '',
        plan: msg.plan || 'trial',
        name: msg.name || '',
        email: msg.email || '',
        expiresAt
      }
    });
  }
});

// ── Analysis pipeline ─────────────────────────────────────────────────────────

async function analyzeEpisode(msg, tabId) {
  if (!tabId) return;

  const sessionKey = 'tab_' + tabId;

  // Store initial state
  await setTabState(sessionKey, {
    status: 'pending',
    step: 0,
    url: msg.url,
    title: msg.title || '',
    channel: msg.channel || '',
    platform: msg.platform || ''
  });

  send(tabId, { type: 'STEP_UPDATE', step: 0 });

  try {
    // Get auth token (optional — API works without, but plan gating requires it)
    const { pl_auth: auth } = await chrome.storage.local.get('pl_auth');
    const headers = { 'Content-Type': 'application/json' };
    if (auth?.token) headers['Authorization'] = 'Bearer ' + auth.token;

    const res = await fetch(`${API}/analyze`, {
      method: 'POST',
      headers,
      body: JSON.stringify({
        url: msg.url,
        episodeTitle: msg.title,
        channelName: msg.channel,
        source: 'extension',
        platform: msg.platform
      })
    });

    if (!res.ok) {
      const errText = await res.text().catch(() => '');
      throw new Error(`API error ${res.status}: ${errText.slice(0, 100)}`);
    }

    const data = await res.json();

    // YouTube → RSS fallback
    if (data.status === 'needs_episode_selection') {
      await setTabState(sessionKey, { status: 'error', error: `Found "${data.showName || msg.channel}" — select a specific episode on Podlens.`, url: msg.url, title: msg.title, channel: msg.channel });
      send(tabId, { type: 'NEEDS_EPISODE_SELECTION', showName: data.showName || msg.channel || '' });
      return;
    }

    const jobId = data.jobId;
    if (!jobId) throw new Error('No job ID returned from API');

    await setTabState(sessionKey, {
      status: 'analyzing',
      step: 1,
      jobId,
      url: msg.url,
      title: msg.title || '',
      channel: msg.channel || '',
      platform: msg.platform || ''
    });

    send(tabId, { type: 'STEP_UPDATE', step: 1 });

    // Poll for results
    await pollJob({ jobId, tabId, sessionKey, url: msg.url, title: msg.title || '', channel: msg.channel || '', platform: msg.platform || '', attempts: 0 });

  } catch (e) {
    const errMsg = e.message?.includes('fetch') ? 'Connection error. Check your internet.' : (e.message || 'Analysis failed.');
    await setTabState(sessionKey, { status: 'error', error: errMsg, url: msg.url, title: msg.title, channel: msg.channel });
    send(tabId, { type: 'ANALYSIS_ERROR', error: errMsg });
  }
}

async function pollJob({ jobId, tabId, sessionKey, url, title, channel, platform, attempts }) {
  if (attempts >= MAX_POLLS) {
    const msg = 'Analysis timed out. Open podlens.app to try again.';
    await setTabState(sessionKey, { status: 'error', error: msg, url, title, channel });
    send(tabId, { type: 'ANALYSIS_ERROR', error: msg });
    return;
  }

  try {
    const s = await fetch(`${API}/status/${jobId}`).then(r => r.json());

    const stepMap = { pending: 0, transcribing: 1, analyzing: 2, partial: 3, complete: 4 };
    const step = stepMap[s.status] ?? 2;

    await setTabState(sessionKey, { status: 'analyzing', step, jobId, url, title, channel, platform });
    send(tabId, { type: 'STEP_UPDATE', step });

    if (s.status === 'error') {
      const errMsg = s.error || 'Analysis failed.';
      await setTabState(sessionKey, { status: 'error', error: errMsg, url, title, channel });
      send(tabId, { type: 'ANALYSIS_ERROR', error: errMsg });
      return;
    }

    if (s.status === 'complete' || s.status === 'partial') {
      const al = s.audioLean || s.politicalLean || {};
      const leftPct = al.leftPct ?? 0;
      const centerPct = al.centerPct ?? 20;
      const rightPct = al.rightPct ?? 0;
      const findings = (s.flags || s.findings || []).slice(0, 2).map(f => ({
        title: f.title || '',
        detail: f.detail || ''
      }));
      const biasLabel = s.biasLabel || computeBiasLabel(leftPct, rightPct);
      const analysisUrl = `${API.replace('/api', '')}/?jobId=${jobId}`;

      const resultState = {
        status: s.status === 'complete' ? 'complete' : 'analyzing',
        step: s.status === 'complete' ? 5 : 3,
        jobId,
        url,
        title,
        channel,
        platform,
        leftPct,
        centerPct,
        rightPct,
        biasLabel,
        findings,
        analysisUrl,
        complete: s.status === 'complete'
      };

      await setTabState(sessionKey, resultState);

      send(tabId, {
        type: 'ANALYSIS_RESULT',
        data: { leftPct, centerPct, rightPct, biasLabel, findings, analysisUrl, complete: s.status === 'complete' }
      });

      if (s.status === 'complete') {
        // Save to recent analyses
        await saveRecent({ episodeTitle: title, channel, leftPct, centerPct, rightPct, biasLabel, analysisUrl, platform });
        // Update final state
        await setTabState(sessionKey, { ...resultState, status: 'complete' });
        return;
      }

      // Partial — keep polling
      setTimeout(() => pollJob({ jobId, tabId, sessionKey, url, title, channel, platform, attempts: attempts + 1 }), 5000);
      return;
    }

    // Still processing
    const delay = attempts < 20 ? 3000 : 5000;
    setTimeout(() => pollJob({ jobId, tabId, sessionKey, url, title, channel, platform, attempts: attempts + 1 }), delay);

  } catch (e) {
    // Network hiccup — retry
    setTimeout(() => pollJob({ jobId, tabId, sessionKey, url, title, channel, platform, attempts: attempts + 1 }), 4000);
  }
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function computeBiasLabel(l, r) {
  const diff = Math.abs(l - r);
  if (diff < 20) return 'Mostly balanced';
  if (diff < 40) return 'Lightly one-sided';
  if (diff < 60) return 'Moderately one-sided';
  if (diff < 80) return 'Heavily one-sided';
  return 'Extremely one-sided';
}

async function setTabState(sessionKey, state) {
  await chrome.storage.session.set({ [sessionKey]: state });
}

async function saveRecent(item) {
  const { pl_recent: recent = [] } = await chrome.storage.local.get('pl_recent');
  const updated = [item, ...recent.filter(r => r.analysisUrl !== item.analysisUrl)].slice(0, 20);
  await chrome.storage.local.set({ pl_recent: updated });
}

function send(tabId, msg) {
  if (tabId) {
    chrome.tabs.sendMessage(tabId, msg).catch(() => {
      // Tab may have navigated away — ignore
    });
  }
}
