// Podlens Extension — content.js
// Runs on YouTube, Spotify, Apple Podcasts, Podbean, SoundCloud

const isYouTube    = location.hostname.includes('youtube.com');
const isSpotify    = location.hostname.includes('spotify.com');
const isApple      = location.hostname.includes('podcasts.apple.com');
const isPodbean    = location.hostname.includes('podbean.com');
const isSoundCloud = location.hostname.includes('soundcloud.com');

// ── Episode detection ─────────────────────────────────────────────────────────

function getEpisodeInfo() {
  if (isYouTube) return getYouTubeInfo();
  if (isSpotify)    return getSpotifyInfo();
  if (isApple)      return getAppleInfo();
  if (isPodbean)    return getPodbeanInfo();
  if (isSoundCloud) return getSoundCloudInfo();
  return null;
}

function getYouTubeInfo() {
  return {
    url: location.href,
    title: (
      document.querySelector('h1.ytd-video-primary-info-renderer yt-formatted-string')?.textContent ||
      document.querySelector('h1.ytd-watch-metadata yt-formatted-string')?.textContent ||
      document.querySelector('#above-the-fold #title h1')?.textContent ||
      document.querySelector('#title h1')?.textContent ||
      document.title.replace(' - YouTube', '')
    ).trim(),
    channel: (
      document.querySelector('#text.ytd-channel-name a')?.textContent ||
      document.querySelector('#channel-name a')?.textContent ||
      document.querySelector('ytd-channel-name a')?.textContent ||
      document.querySelector('#owner-name a')?.textContent ||
      ''
    ).trim(),
    platform: 'youtube'
  };
}

function getSpotifyInfo() {
  return {
    url: location.href,
    title: (
      document.querySelector('[data-testid="entityTitle"]')?.textContent ||
      document.querySelector('h1[data-encore-id="type"]')?.textContent ||
      document.querySelector('span[data-encore-id="type"][class*="Title"]')?.textContent ||
      document.title.replace(' | Spotify', '')
    ).trim(),
    channel: (
      document.querySelector('[data-testid="creator-link"]')?.textContent ||
      document.querySelector('a[href*="/show/"]')?.textContent ||
      ''
    ).trim(),
    platform: 'spotify'
  };
}

function getAppleInfo() {
  // Apple Podcasts uses meta tags for episode data
  const og_title = document.querySelector('meta[property="og:title"]')?.content || '';
  const desc = document.querySelector('meta[property="og:description"]')?.content || '';
  return {
    url: location.href,
    title: (
      document.querySelector('.product-header__title')?.textContent ||
      document.querySelector('h1.section__headline')?.textContent ||
      og_title ||
      document.title.replace(' on Apple Podcasts', '').replace(' - Apple Podcasts', '')
    ).trim(),
    channel: (
      document.querySelector('.product-header__identity a')?.textContent ||
      document.querySelector('.link-action')?.textContent ||
      ''
    ).trim(),
    platform: 'apple'
  };
}

function getPodbeanInfo() {
  return {
    url: location.href,
    title: (
      document.querySelector('.ep-title')?.textContent ||
      document.querySelector('h1.title')?.textContent ||
      document.querySelector('meta[property="og:title"]')?.content ||
      document.title
    ).trim(),
    channel: (
      document.querySelector('.podcast-title a')?.textContent ||
      document.querySelector('meta[name="author"]')?.content ||
      ''
    ).trim(),
    platform: 'podbean'
  };
}

function getSoundCloudInfo() {
  return {
    url: location.href,
    title: (
      document.querySelector('.soundTitle__title span')?.textContent ||
      document.querySelector('.playbackSoundBadge__titleLink span[aria-label]')?.getAttribute('aria-label') ||
      document.querySelector('meta[property="og:title"]')?.content ||
      document.title
    ).trim(),
    channel: (
      document.querySelector('.soundTitle__username')?.textContent ||
      document.querySelector('meta[name="author"]')?.content ||
      ''
    ).trim(),
    platform: 'soundcloud'
  };
}

// ── Sidebar injection ─────────────────────────────────────────────────────────

function buildSidebar(info) {
  const platformLabel = {
    youtube: 'YouTube', spotify: 'Spotify', apple: 'Apple Podcasts',
    podbean: 'Podbean', soundcloud: 'SoundCloud'
  }[info.platform] || info.platform;

  const platformClass = {
    youtube: '#FF0000', spotify: '#1DB954', apple: '#FC3C44',
    podbean: '#F0701E', soundcloud: '#FF5500'
  }[info.platform] || '#555';

  return `
    <div class="pl-header">
      <span class="pl-logo">
        <svg width="20" height="20" viewBox="0 0 90 90" fill="none">
          <circle cx="45" cy="45" r="40" stroke="rgba(255,255,255,0.12)" stroke-width="2"/>
          <circle cx="41" cy="42" r="26" stroke="rgba(255,255,255,0.24)" stroke-width="2"/>
          <circle cx="47" cy="48" r="13" stroke="rgba(255,255,255,0.5)" stroke-width="2.5"/>
          <circle cx="45" cy="45" r="5.5" fill="white"/>
        </svg>
        <span class="pl-pod">POD</span><span class="pl-lens">LENS</span>
      </span>
      <button class="pl-close" id="pl-close" title="Close Podlens">&#x2715;</button>
    </div>
    <div class="pl-episode" id="pl-ep">
      <span style="display:inline-block;background:${platformClass};color:white;font-size:9px;font-weight:700;padding:2px 6px;border-radius:2px;margin-bottom:5px;letter-spacing:.04em">${platformLabel}</span><br>
      <span id="pl-ep-title"></span>
      <div id="pl-ep-channel" style="font-size:10px;color:#aaa;margin-top:2px"></div>
    </div>
    <div class="pl-body">
      <div id="pl-loading">
        <div class="pl-spinner"></div>
        <div id="pl-steps">
          <div class="pl-step" data-s="0">&#128269; Extracting transcript...</div>
          <div class="pl-step" data-s="1">&#128202; Identifying topics...</div>
          <div class="pl-step" data-s="2">&#9878;&#65039; Analyzing framing...</div>
          <div class="pl-step" data-s="3">&#128100; Evaluating host trust...</div>
          <div class="pl-step" data-s="4">&#128270; Detecting missing voices...</div>
        </div>
        <div class="pl-eta">Usually 30&#x2013;90 seconds</div>
      </div>
      <div id="pl-results" style="display:none">
        <div class="pl-lbl">POLITICAL LEAN</div>
        <div class="pl-bar-wrap">
          <div id="pl-bar"></div>
        </div>
        <div id="pl-pcts"></div>
        <div id="pl-plain"></div>
        <div id="pl-findings"></div>
        <a class="pl-btn" id="pl-link" href="https://podlens.app" target="_blank" rel="noopener">
          See full analysis &#x2197;
        </a>
        <div id="pl-share-row" style="display:flex;gap:6px;margin-top:8px">
          <button id="pl-copy-btn" style="flex:1;padding:5px 4px;font-size:10px;font-weight:600;border-radius:3px;border:1px solid #e0ddd8;background:#FAF9F6;color:#555;cursor:pointer;font-family:inherit">&#128203; Copy</button>
          <button id="pl-x-btn" style="flex:1;padding:5px 4px;font-size:10px;font-weight:600;border-radius:3px;border:1px solid #e0ddd8;background:#FAF9F6;color:#555;cursor:pointer;font-family:inherit">&#120143; Share</button>
        </div>
      </div>
      <div id="pl-error" style="display:none">
        <p id="pl-msg"></p>
        <a class="pl-btn" href="https://podlens.app" target="_blank" rel="noopener" id="pl-error-link">
          Analyze on Podlens &#x2197;
        </a>
      </div>
    </div>
    <div class="pl-footer">
      Powered by <a href="https://podlens.app" target="_blank" rel="noopener" style="color:#9B8F82;text-decoration:none;font-weight:500">podlens.app</a>
    </div>
  `;
}

function injectSidebar() {
  if (document.getElementById('podlens-sidebar')) return;
  const info = getEpisodeInfo();
  if (!info) return;

  const sidebar = document.createElement('div');
  sidebar.id = 'podlens-sidebar';
  sidebar.innerHTML = buildSidebar(info);
  document.body.appendChild(sidebar);

  // Fill episode info
  const titleEl = document.getElementById('pl-ep-title');
  if (titleEl) titleEl.textContent = (info.title || 'Analyzing episode').substring(0, 90);
  const channelEl = document.getElementById('pl-ep-channel');
  if (channelEl && info.channel) channelEl.textContent = info.channel;

  // Close button
  document.getElementById('pl-close').onclick = () => {
    sidebar.remove();
    document.body.classList.remove('pl-sidebar-open');
  };

  // Push page layout
  document.body.classList.add('pl-sidebar-open');

  // Start analysis
  chrome.runtime.sendMessage({
    type: 'ANALYZE',
    url: info.url,
    title: info.title,
    channel: info.channel,
    platform: info.platform
  });
}

// ── Message handler ───────────────────────────────────────────────────────────

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {

  if (msg.type === 'GET_EPISODE_INFO') {
    const info = getEpisodeInfo();
    sendResponse(info || null);
    return true;
  }

  if (msg.type === 'TRIGGER_ANALYSIS') {
    const existing = document.getElementById('podlens-sidebar');
    if (existing) {
      existing.remove();
      document.body.classList.remove('pl-sidebar-open');
    }
    const info = getEpisodeInfo();
    if (info) setTimeout(injectSidebar, 100);
    return;
  }

  if (msg.type === 'CANCEL_ANALYSIS') {
    document.getElementById('podlens-sidebar')?.remove();
    document.body.classList.remove('pl-sidebar-open');
    return;
  }

  if (msg.type === 'STEP_UPDATE') {
    document.querySelectorAll('.pl-step').forEach((el, i) => {
      el.classList.remove('active', 'done');
      if (i < msg.step) el.classList.add('done');
      else if (i === msg.step) el.classList.add('active');
    });
    return;
  }

  if (msg.type === 'ANALYSIS_RESULT') {
    const loading = document.getElementById('pl-loading');
    const results = document.getElementById('pl-results');
    if (!loading || !results) return;

    loading.style.display = 'none';
    results.style.display = 'block';

    const l = msg.data.leftPct || 0;
    const c = msg.data.centerPct || 0;
    const r = msg.data.rightPct || 0;

    const bar = document.getElementById('pl-bar');
    if (bar) bar.style.background = `linear-gradient(to right, #E24B4A ${l}%, #D1CFC9 ${l}% ${l + c}%, #378ADD ${l + c}%)`;

    const pcts = document.getElementById('pl-pcts');
    if (pcts) pcts.innerHTML = `<span style="color:#E24B4A">&#128308; ${l}% left</span> &middot; <span style="color:#999">${c}% center</span> &middot; <span style="color:#378ADD">&#128309; ${r}% right</span>`;

    const plain = document.getElementById('pl-plain');
    if (plain) plain.textContent = msg.data.biasLabel || '';

    const findings = document.getElementById('pl-findings');
    if (findings && msg.data.findings?.length) {
      findings.innerHTML = msg.data.findings.slice(0, 2).map(f =>
        `<div class="pl-finding"><strong>${f.title || ''}</strong>${f.detail ? ` &mdash; <span style="font-weight:400">${f.detail}</span>` : ''}</div>`
      ).join('');
    }

    const link = document.getElementById('pl-link');
    if (link && msg.data.analysisUrl) link.href = msg.data.analysisUrl;

    // Copy button
    const copyBtn = document.getElementById('pl-copy-btn');
    if (copyBtn && msg.data.analysisUrl) {
      copyBtn.onclick = () => {
        navigator.clipboard.writeText(msg.data.analysisUrl).then(() => {
          copyBtn.textContent = '✓ Copied!';
          setTimeout(() => { copyBtn.textContent = '📋 Copy'; }, 1800);
        });
      };
    }

    // X share button
    const xBtn = document.getElementById('pl-x-btn');
    const info = getEpisodeInfo();
    if (xBtn && msg.data.analysisUrl) {
      xBtn.onclick = () => {
        const text = encodeURIComponent(`"${info?.title || 'This podcast'}" analyzed on Podlens — see the political lean:`);
        window.open(`https://twitter.com/intent/tweet?text=${text}&url=${encodeURIComponent(msg.data.analysisUrl)}`, '_blank');
      };
    }

    return;
  }

  if (msg.type === 'NEEDS_EPISODE_SELECTION') {
    const loading = document.getElementById('pl-loading');
    const error = document.getElementById('pl-error');
    if (!loading || !error) return;
    loading.style.display = 'none';
    error.style.display = 'block';
    const msgEl = document.getElementById('pl-msg');
    if (msgEl) msgEl.textContent = `Found "${msg.showName}" — select a specific episode on Podlens.`;
    const errLink = document.getElementById('pl-error-link');
    if (errLink) errLink.href = `https://podlens.app?show=${encodeURIComponent(msg.showName || '')}`;
    return;
  }

  if (msg.type === 'ANALYSIS_ERROR') {
    const loading = document.getElementById('pl-loading');
    const error = document.getElementById('pl-error');
    if (!loading || !error) return;
    loading.style.display = 'none';
    error.style.display = 'block';
    const msgEl = document.getElementById('pl-msg');
    if (msgEl) msgEl.textContent = msg.error || 'Could not analyze this episode.';
    return;
  }
});

// ── Auto-inject on page load ──────────────────────────────────────────────────

function tryInject() {
  if (document.getElementById('podlens-sidebar')) return;
  injectSidebar();
}

if (['complete', 'interactive'].includes(document.readyState)) {
  setTimeout(tryInject, 800);
} else {
  window.addEventListener('load', () => setTimeout(tryInject, 800));
}

// ── YouTube SPA navigation ────────────────────────────────────────────────────

if (isYouTube) {
  let lastUrl = location.href;

  const cleanupSidebar = () => {
    document.getElementById('podlens-sidebar')?.remove();
    document.body.classList.remove('pl-sidebar-open');
  };

  new MutationObserver(() => {
    if (location.href !== lastUrl) {
      lastUrl = location.href;
      cleanupSidebar();
      if (/youtube\.com\/watch/.test(location.href)) {
        setTimeout(tryInject, 2500);
      }
    }
  }).observe(document, { subtree: true, childList: true });

  document.addEventListener('yt-navigate-finish', () => {
    if (/youtube\.com\/watch/.test(location.href) && location.href !== lastUrl) {
      lastUrl = location.href;
      cleanupSidebar();
      setTimeout(tryInject, 2500);
    }
  });
}
